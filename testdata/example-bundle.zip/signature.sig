{
  "schema_version": 1,
  "algorithm": "ed25519",
  "key_fingerprint_spki_b64": "MCowBQYDK2VwAyEAIdvXBrE70QSF8Tmo7Kct7gU66qRRxu45gTxGOj8OpjE=",
  "signed_artifact": "manifest.json",
  "signature_b64": "rams1eBj3iNlp/xkQ8V0rI6gdNcfPLolrnTQ5xJL0SKbraAPbvCY5df0srofYkvFcnu/6qouzwzKgjvmaaCJCw=="
}
