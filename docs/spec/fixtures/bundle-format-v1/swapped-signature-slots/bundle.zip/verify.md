# Verification — NuWyre evidence bundle

This document describes how an external party (compliance officer,
forensic reviewer, regulator, journalist, curious engineer) can
independently verify this bundle's integrity end-to-end. The bundle
covers the day 2026-04-22 UTC.

> ⚠ **DEMO BUNDLE** — this bundle is signed with the development key (`issuer-dev-v1`), not the production customer-export key. The Phase 4 verification CLI will emit the same warning even on a successful verify.

This is a **`nuwyre-bundle/v2`** bundle (v2.0.0-rc1 dual-signature topology per spec §§18.1-18.10). Both an Ed25519 signature AND a ML-DSA-65 (FIPS 204) post-quantum signature cover the manifest. Both MUST verify for the bundle to be considered authentic — a single-algorithm failure is sufficient grounds for rejection.

The Phase 4 NuWyre verification CLI automates all of these checks
into a single `nuwyre verify ./bundle.zip` invocation. Until the
CLI ships at your platform, the checks below can be performed
manually using standard cryptographic tooling.

The verification checks correspond exactly to the CLI's documented behavior — automated and manual paths produce the same verdict. v2 bundles emit between **seven and nine** checks depending on topology + bundle_type per spec §14.1 omit-inapplicable pattern: the typical v2 customer-export bundle (single-key topology; non-audit-log-export) emits exactly **seven entries** (Checks 1-7); ephemeral-sessions topology adds Check 8 (sandbox-preview only — out of scope at v2.0.0-rc1); audit-log-export bundle_type adds Check 9 (out of scope for v2.0.0-rc1 customer-export). Check 1 itself is the dual-signature variant per spec §§18.1-18.10 in every v2 case.

---

## Check 1 — Manifest dual-signature (Ed25519 + ML-DSA-65)

`signature.sig` is a JSON multi-signature container per spec §18.2.
It carries TWO signatures over the IDENTICAL canonical `manifest.json`
byte sequence:

- **`signatures[0]`** — Ed25519 signature (RFC 8032; 64 bytes raw,
  base64 encoded with `==` padding = 88 characters)
- **`signatures[1]`** — ML-DSA-65 post-quantum signature (FIPS 204
  final, August 2024; 3309 bytes raw, base64 encoded with NO padding
  = 4412 characters since 3309 mod 3 = 0)

**Both signatures MUST verify** for the bundle to be considered
authentic per spec §18.7 step 5. A single-algorithm verification
failure (Ed25519 passes but ML-DSA-65 fails, or vice versa) is
sufficient grounds for rejection — even though one algorithm still
attests to integrity, the dual-signing topology's defense-in-depth
guarantee is violated.

The pinned SPKI fingerprints, both at the **dev slot**:

```
signatures[0] (Ed25519, RFC 5280 SPKI DER, 44 bytes raw / 60 chars
base64 with `==` padding):
MCowBQYDK2VwAyEAIdvXBrE70QSF8Tmo7Kct7gU66qRRxu45gTxGOj8OpjE=

signatures[1] (ML-DSA-65, canonical 1974-byte SPKI DER per spec §18.4,
2632 chars base64 with no padding):
MIIHsjALBglghkgBZQMEAxIDggehADkSk4wnXVAO09DnxMba66mJxZSO7Q5i6IfyAw4MOfJLg0gUnG+VhVuoqb4bQVJtqdQ2/AQ+NKjf9YCXwDT0u0RkFJ4MlX03nBT/hBHMozCzWYW5FZVgz8Ugu7/9Ah9BO+Bzo47kluSK2TZX7iBKL3+UjcWQ+mAPV6ILyu76gkbmg2u9dPcAZglbsM1kDskeUMvqeMd2peP0LlItjC1vmQ01aFEBmdeTQKWFB6WB1k9O9MwKddax7EEeCDDZOcuh422rFMNDDNbIObq+73TaDkelYvwYnCePi95FZEZPXt9khin/EX4QnmAVayYoEzU0Ngu4DQyll31m+e1sKp6iRWsUl3k/P7rVaLid7x8KAdsfTCyNN32HhNfR+j4F5WLyzT8SoWM4KcXiomDuNNw4iPGNIjxdsXn8LMEVXmu12jIdWW2PeBhpqB8jC1GaGT2ikaEo785C2NmxHslkWjc/2lTrznV61lyxCbEz3ahFBlA/we99BrAyXzfezJZCg3ygQ2c2b6XV0ptfEch+4I3RQNhaQkebz821vLirXSixdb7WflbpdydYU2ruOsvGVeNcfOwGWNk4RF0R5zPzus6is/90h0V99hkBnRTuMwVZc3TVO3EqAtQjysudJrkEzd1y3aSAbTSVOpHNpYzge/LdSHrimdi1P06WaQRWwSs8haU/i3pA4zlK4XMhjgMY62dzJpW2S3hyDAjNuFcOx76xs5wpvB0n+cddpuLSVi7zMn86gB0MxMjVwJmOdIznwA7mB3rcY/CdYoSsKeVmRKz6iJO0J7Yrz/lf3LOYhu1shqc9FBaSLXLR/RqcGu8Ezz6RUBC+EFD03MPdkAx/SdDXAqFkhCywrpEnrSfcIcY5/KQi+5uIuN4ISTW1LEQ+5ok+r65SUw2qV8JgGwPpk0qPVdHAzArfQgHQRFFxi78PaAPHa26dWNAp8EPKFZZ32r2qKYk1681XYiMd4G0yCCtJGwpbSIoZCTMZJqYfJA0zA+IEqq9gy1GF5zDoD1rcfCIlYwMZvO5qoxLEo1S5ehCqp6o1wfa84tzVI4aKH0f96IQubd8YD2GsA7RRkjtgxdkWZRYjDmnDV2qJeZ7ZlfhFrIlpsOxX6a5W75lMQd5rp03hRnCHx1npQVlu+w6b3El4RMX4FSvMAw4BwK3THRSJql1b3bKlJ21M1Aqsk1Gjfh+Gxk2vC35PTRI7c+gDl+aM1xzHk4VZyG/j14smleELyJpeggSf5MuUYwGekEj0vqZOgNrD2HwMw9uS7aF2RnVpZSjVZpNDOaClI+oE/+bWOqvZjwB7OdZ1z4Va711yDxjuumuvY8e7fcIMNW2ShGpOnMlMfQI+In/kgtmZimWx6zvsZ2DM9HZwmmgy/+zV7bOWRYHeYDL3ieOSuw6H+mnAPok2e8XQbTLYAgQTgt+rDVy6C2VqIhwduwJQPXkGlSjPB2BHmp3PATzU/GnNeA/ANeTgK/MTJyO7Qn3/hr1kZsV1sYxJJV99AyFXSSyB8Kd6XjA0pyjZ4HK6hXhytzqLTLD7F3kKUmu5QaPwxCCPpPtsu+pNwjcTQhK1a54G2c0PkxGnQctiRiTDuBBEmyQdj1SfGmP0zxlot+1fw6aEjEV5vToL4U1n/qlSjx0s3qHoj76PO1xyIXtvEPseBV+ZaSmpEvDXEbT37IUGk8zWePHiSnVNJQDUVBlV276fjDxbf8TnU3tx+WRIhBD2QglvCg3b6XGKkk4Cegboe1Y8M+wZsuen7vq6drGr41sIUmApS2oeklIhhLgm+2y+z1cLCXXRokQxKCYvjfbaZA9KLrIay5jOZXWp85dDqjn6VYXsApOYgeZ7SnWVozjjRZAYnyZhpJT4P3oJmZc388ECJmCKtr4HJ2gdd+z7YH2+QGablxhktnaZUxm/EfgmwlrwyDq3cEYBYFrc8sdMZHszXaaCjEKkNukeLG8ngucargt3Th4F5yfrTU997wjwr9VWd5yATQf8wka7IdEPE/jWXi0FhhFHfYLGLJWZTONRLmKa37c3uR8rJ8NbW01N4ojqgU80zqhDsai+x/LeGvq2BmEUbcefE3p/ojtzdEEuNTjwPiEh6WMMRB7CmXFIm5gjR0hA0orGkjobwvHqAVwf4qybZkI/N3NX0oX1aQgJqYuIGSWC9baf3WtcjoB5LRP6IhHJKRN0+q243XSTxVM/XRieUNKqfH3YBv64B3z1gJbHBJmpfv/wk2KeY+qQEeFpFGyac8aLAzj4rWsDY22AyM2eM+KriGvojLxWmPZlN6DJ1+p8VkoBuztxiPvy/P3xCaXcLz0uZbrbEytaLI1i8hJX/kRRP0B01KNgK9t1+Iz/afqSxV+aHsDf8W/gfwWog1VjwdO2LrHIajWfHUuO2308uLuXblY3MHlKr5x6e8xOE5bWO+TBRJcN9BIJWxrtl/VJscNA8i0hktmg1+HwyobC3AtMSEdRgWLbl7I+xYkb1RDDdoRLfxuu1JP5STeBWchug9gzv4l/EPt+3Vep+KUzh6p/yTfvwU88XVZo4s9/n/uhJh4eU5ZvW+hTBMQoe7kGvXUbYjxZmOwtdZLV5TJA/4PThYULo6Ly32bllriC
```

**Cross-environment-slot discipline (spec §18.6)**: both signing
keys MUST belong to the same environment slot — both prod OR both
dev. A bundle with mixed-slot signatures (e.g., one prod key + one
dev key) MUST fail Check 1. Per spec §18.7 step ordering, the
verifier inspects the key_ids declared in
`manifest.signing.signatures[i]` and `signature.sig:signatures[i]`,
confirms they agree, and rejects mixed-slot combinations at the
**§18.7 step 2 schema-cross-check** (BEFORE the §18.7 step 3
pinned-key directory lookup and the §18.7 step 5 cryptographic
verification).

**Reading the verifier's dual-algorithm verdict (spec §18.10)**: the
verifier emits a structured per-algorithm verdict at
`checks[0].algorithm_verdicts` — an array of exactly 2 entries
`[{algorithm: "ed25519", status: "pass"|"fail"}, {algorithm:
"ml-dsa-65", status: "pass"|"fail"}]`. CI tooling, dispute-
investigation tools, and operator dashboards consuming the verifier's
`--json` output SHOULD parse `algorithm_verdicts` as the
canonical-source for the dual-algorithm verdict; the natural-language
strings in `errors[]` / `warnings[]` are implementation-localized
and IGNORED by the conformance contract.

**signature.sig is itself RFC 8785 JCS-canonicalized** per spec §18.2
when written into the bundle ZIP. This enables byte-equivalent cross-
language verification: a Go-impl verifier reading the same on-disk
bytes will compute the same SHA-256 as a TS-impl verifier.
Canonical alphabetical key ordering applies at TWO levels:
top-level container `{schema_version, signatures, signed_artifact}`
(note `signatures` < `signed_artifact` by codepoint sort — `a`
(0x61) < `e` (0x65) at position 4); per-entry signatures[i]
`{algorithm, key_fingerprint_spki_b64, key_id, signature_b64}`.
Implementations MUST invoke a JCS-conformant canonicalizer library
rather than relying on language-native JSON encoders (Go
`encoding/json` and TS `JSON.stringify` both produce non-JCS output
by default).

**Why dual signing?** The Ed25519 + ML-DSA-65 composition is the
post-quantum hedge per spec §15.2: any single algorithm being broken
in the future (whether classical cryptanalysis on Ed25519 OR a
cryptographically-relevant quantum computer breaking Curve25519
discrete-log) does NOT invalidate v2 bundles' integrity — both
algorithms would need to be simultaneously broken for forgery. NIST
projections for CRQC against Curve25519 sit at ~2035-2040; v2.0.0-rc1+
bundles emitted in 2026 remain hostile-re-verification-defensible
through that horizon.

## Check 2 — Artifact integrity

For each artifact listed in `manifest.json:artifacts`, compute the
SHA-256 of the artifact's bytes and verify it matches the listed
`sha256` value.

```bash
shasum -a 256 events.jsonl
# compare to manifest.artifacts[<events.jsonl>].sha256
```

This includes audio files: each `audio/<sha256>.<ext>` MUST hash to
its filename stem AND match the `sha256` claim in manifest.

Any mismatch means an artifact has been modified after manifest
construction. Stop and treat the bundle as compromised.

**v2 amendment** (spec §18.5): the bundle ZIP file-set MUST equal
`{manifest.json, signature.sig} ∪ {artifacts[].path}` as a set.
An extra file in the ZIP not listed in manifest.artifacts[] (and not
`manifest.json` or `signature.sig`) MUST fail Check 2. Verifiers
also reject ZIPs with duplicate filenames before computing set
equality (attacker-controlled smuggling surface).

## Check 3 — Hash chain reconstruction

For each line in `events.jsonl`, recompute `content_hash` (SHA-256
of the canonicalized content fields) and `event_hash` (SHA-256 of
prev_event_hash + content_hash + sequence_number + timestamp_unix_ns).
Verify each event's `forensic.event_hash` matches the recomputed
value AND `forensic.prev_event_hash` matches the previous event's
hash (or `GENESIS_PREV_HASH` for sequence_number = 0).

A break in the chain (any divergence in any event) means events have
been altered, removed, or inserted post-ingestion.

## Check 4 — Merkle proof verification

For each event with a Merkle proof in `merkle_proofs.json`, verify
the proof against the relevant daily root. Single-day bundles have
one root in `daily_roots.json` matching the proofs' `root` field
verbatim; multi-day bundles have one daily root per day, and each
proof's `root` field identifies which day's tree it verifies
against. The verifier walks the proof's path from leaf to root,
hashing pair-wise SHA-256, and confirms the final value equals the
proof's `root`.

## Check 5 — OpenTimestamps Bitcoin anchor

For each daily root with an `.ots` receipt in `ots_receipts/`,
verify against the public Bitcoin chain. Receipts in `pending`
state pass with a warning unless `--strict-ots` is set; once the
Bitcoin block confirmation lands (typically within ~24h of OTS
submission), the receipt upgrades to `confirmed` with a Bitcoin
block height recorded.

## Check 6 — RFC 3161 timestamp anchor

For each daily root, verify each `.tsr` (RFC 3161 timestamp token)
against its **embedded `.chain.pem`** (captured at stamping time,
shipped in the bundle). At least 2 of 3 distinct TSAs must produce
verifying `{ token, chain }` pairs per daily root — single-TSA
failure does NOT fail check 6 unless it drops verification below
the two-of-three threshold.

Chain validation uses the system trust store first, then a small
set of pinned TSA roots (FreeTSA, Sectigo, DigiCert, USERTrust); no
live TSA infrastructure is required at verification time.

## Check 7 — GitHub anchor cross-check

Fetch the public anchor repo at the recorded `commit_sha` (from
`github_anchors/<date>.json`), confirm the file at
`daily-roots/<YYYY-MM-DD>/root.json` exists, and confirm its
content's `root_hash` matches the bundle's `daily_roots.json`
claim for that date. Also verify the commit's SSH signature
against the pinned issuer key.

For example-demo bundles or pre-Phase-5 customer exports, the
github_anchor JSON ships with `mirror_status: "anchor-pending"`;
check 7 is skipped with a note.

---

## Tooling

- The Phase 4 verification CLI is the canonical automation. Distribution + install instructions: https://verify.nuwyre.com.
- Manual checks: `shasum`, `openssl` (for chain validation against the embedded PEMs), `opentimestamps-client` (for Bitcoin verification), `git` (for the GitHub anchor cross-check).
- **ML-DSA-65 (FIPS 204 post-quantum) verification**: use a FIPS 204-conformant library that supports the deterministic-variant signing API per spec §18.3. Candidate libraries include `@noble/post-quantum` (TypeScript), `cloudflare/circl/sign/mldsa` (Go), `liboqs` (C; via Open Quantum Safe). Verify the canonical 1974-byte SPKI DER + 3309-byte signature byte counts per spec §18.4.
- The bundle-format spec at `/docs/spec/bundle-format-v1.md` is the authoritative cross-language contract; both the TypeScript writer and the Go verifier conform to it.
