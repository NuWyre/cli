# Verification — example evidence bundle

This document describes how an external party (compliance officer,
forensic reviewer, regulator, journalist, curious engineer) can
independently verify this bundle's integrity end-to-end.

The Phase 4 NuWyre verification CLI automates all of these checks
into a single `nuwyre verify ./bundle.zip` invocation. Until the
CLI ships, the checks below can be performed manually using
standard cryptographic tooling.

---

## Step 1 — Manifest integrity

For each artifact listed in `manifest.json`'s `artifacts` array,
compute SHA-256 of the artifact's bytes and verify it matches the
listed `sha256` value.

```bash
shasum -a 256 events.jsonl
# compare to manifest.artifacts[<events.jsonl>].sha256
```

Any mismatch means an artifact has been modified after manifest
construction. Stop and treat the bundle as compromised.

## Step 2 — Manifest signature

The `signature.sig` artifact is an Ed25519 signature over the
`manifest.json` file's bytes by the dev signing key.

The dev key's SPKI fingerprint (base64) is pinned at:

```
MCowBQYDK2VwAyEAIdvXBrE70QSF8Tmo7Kct7gU66qRRxu45gTxGOj8OpjE=
```

Verify that:

1. `signature.key_fingerprint_spki_b64` matches the pinned value above.
2. The Ed25519 signature in `signature.signature_b64` validates against
   the dev public key over `manifest.json` bytes.

The dev public key is published at
`packages/example-bundle/dev-keys/dev-signing-key.pub.json` in the
NuWyre repository.

## Step 3 — Merkle root

`merkle_proofs.json` declares the root and per-event proofs. To
verify:

1. Read all event_hash values from `events.jsonl` (each event's
   `forensic.event_hash`).
2. Sort them ascending and pad to the next power of two with the
   genesis sentinel hash (64 zero hex chars).
3. Recompute the merkle tree: each internal node is
   SHA-256(decoded_left || decoded_right), re-encoded as 64-char
   lowercase hex.
4. Compare the resulting root to `merkle_proofs.json`'s `root` AND
   to `daily_roots.json`'s entry for 2026-04-22 AND to
   `manifest.json`'s `daily_root`.

All three values must agree.

## Step 4 — Per-event proofs

For each proof in `merkle_proofs.json.proofs`, walk the path from
the leaf to the root:

```
current = leaf
for step in path:
    if step.position == "left":
        current = sha256(decode_hex(step.sibling) || decode_hex(current))
    else:
        current = sha256(decode_hex(current) || decode_hex(step.sibling))
assert current == proof.root
```

Any failed proof means the corresponding event was added or modified
after the merkle tree was built.

## Step 5 — Per-event chain

Within each session, events form a hash chain via `forensic.prev_event_hash`.
The first event in a session has `prev_event_hash` equal to 64 zero
hex chars (the genesis sentinel). Each subsequent event's
`prev_event_hash` must equal the previous event's `event_hash`.

A break in the chain means an event was inserted, removed, or modified.

## Step 6 — OpenTimestamps anchor

`ots_receipts/2026-04-22.ots` is an OpenTimestamps proof for the
daily merkle root.

To verify:

```bash
pip install opentimestamps-client
ots verify ots_receipts/2026-04-22.ots --hash <daily_root_hex>
# or
ots upgrade ots_receipts/2026-04-22.ots
```

`ots upgrade` folds in Bitcoin block proofs once the OTS calendars
publish them (typically within 24 hours of submission). The
upgraded proof anchors the daily root to a specific Bitcoin block,
making forgery economically impractical.

For example bundles, `opentimestamps.status` in the manifest may be
`submitted-pending-bitcoin-confirmation` until the upgrade completes.

## Step 7 — RFC 3161 timestamp anchors (3 attempted, ≥2 required)

The bundle's `rfc3161_receipts/` directory contains one `.tsr`
(RFC 3161 TimeStampResp) per TSA that returned a valid receipt, plus
the matching `.chain.pem` capturing the TSA's signing certificate
chain at stamping time. Default TSAs are FreeTSA, Sectigo, and
DigiCert; ≥2 of 3 must verify for the bundle's
`anchor_status.rfc3161_status` to be `verified`.

To verify a single `.tsr`:

```bash
# Using the open-source @nuwyre/integrations/rfc3161 client OR the
# Phase 4 verification CLI, parse the .tsr, extract its TSTInfo, and:
#  1. Confirm TSTInfo.messageImprint matches the daily_root hash
#  2. Verify the CMS signature against the captured .chain.pem
#  3. Confirm the chain's signer cert is consistent with the TSA's
#     identity (subject CN includes the expected TSA name)
```

Each `.chain.pem` is captured at stamping time (per build plan
v3.1.2 §"TSA certificate chains embedded at stamping time") so the
bundle remains verifiable even when CAs rotate years after stamping.
Do NOT attempt to verify the chain against a TSA's currently-published
chain — chain rotation between stamping and verification is expected.

## Step 8 — Audio binding (when audio_ref events are present)

Events with `content.audio_ref.hash` reference an audio file at
`audio/<hash>.<ext>` inside the bundle. The audio file's SHA-256
must equal the audio_ref.hash. This binding makes the audio recording
itself tamper-evident — modifying the audio bytes after ingestion
changes the hash, which changes content_hash, which breaks the chain.

```bash
shasum -a 256 audio/<hash>.<ext>
# must equal the audio_ref.hash for the corresponding event
```

The bundle's `manifest.json` includes an `audio_records` array
with sha256 + bytes + duration_ms + mime_type per audio file as a
convenience for verifiers and indexers; the load-bearing check is
the per-event audio_ref.hash equality with the file at
`audio/<hash>.<ext>`.

## Step 9 — GitHub anchor

In production customer bundles, the daily root is also committed to
a public NuWyre anchors repository (`https://github.com/NuWyre/anchors`),
providing a third independent witness in addition to OpenTimestamps
and RFC 3161. For this example bundle,
`anchors.github.mirror_status` may be `anchor-pending` if the
manual signed commit hasn't landed yet (the commit is a deliberate
human action, kept out of the generator's normal flow). When
populated, verify the commit_sha references a real signed commit in
`https://github.com/NuWyre/anchors` whose `daily-roots/2026-04-22/`
tree contains the daily root JSON.

---

## Cross-reference to the validation suite

`scenario_index.json` maps each event in this bundle to the
validation scenario that produced it. Every scenario is publicly
available at `validation/scenarios/<regime>/<scenario-id>.yaml` in
the NuWyre repository. Forensic reviewers can compare each event in
`events.jsonl` against the source scenario to confirm the event
sequence is byte-identical, then compare each evaluation in
`evaluations.jsonl` against the scenario's documented
`expected.primary_flag` to confirm the evaluation is consistent
with the published label.
