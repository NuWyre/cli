{
  "schema_version": 1,
  "algorithm": "ed25519",
  "key_fingerprint_spki_b64": "MCowBQYDK2VwAyEAIdvXBrE70QSF8Tmo7Kct7gU66qRRxu45gTxGOj8OpjE=",
  "signed_artifact": "manifest.json",
  "signature_b64": "sdMC7m5ESBMfgxLR+V3riQ9uOK0BBf4W7b3Lv+b8LsEWAKJAWuz7y5MtJ44azlsuRxznXQiJoa/9PRB1uymBDA=="
}
